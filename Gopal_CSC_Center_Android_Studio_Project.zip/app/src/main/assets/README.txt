GOPAL CSC CENTER - ANDROID-FRIENDLY WEB APP STARTER

Included:
- Marathi, Hindi and English interface
- Customer service request form
- Local application reference and tracking
- Admin dashboard to update application status
- WhatsApp contact link

IMPORTANT LIMITATIONS:
- This is a working front-end prototype/PWA source, not a signed Android APK.
- Applications and the demo Admin password are stored only in the current browser/device using local storage.
- It does NOT sync between customer and admin devices.
- The first Admin password is a local demo password, not secure production authentication.
- Before public launch, connect a secure backend/database, server-side Admin authentication, OTP provider, backups, privacy policy and payment gateway.
- UPI payments are not enabled yet.
- Do not collect Aadhaar numbers, OTPs, biometric data, or sensitive identity documents through this prototype. Use authorized official portals for regulated services.

TO TEST:
1. Upload the files to an HTTPS static host (for example, your own hosting).
2. Open the hosted URL on Android Chrome.
3. Use Chrome menu > Add to Home screen / Install app.
4. Customer applications created on one device will only be visible on that same device until a backend is connected.

For a real Android APK, wrap this PWA in an Android project (e.g. Trusted Web Activity or native WebView) and build/sign it with Android tooling after backend integration.

UPI FEE UPDATE:
- UPI ID configured: 7875277904@ybl
- Admin can set a fee for each service in the Admin Dashboard.
- Customer gets a UPI payment intent link for the amount set by Admin.
- Payment status is NOT verified automatically. Admin must verify the credit in the bank/UPI app.
- Fees and applications remain local to the device in this prototype. For real customer/admin multi-device use, connect a secure backend and a payment gateway with server-side webhook verification.

DIGITAL SIGNATURE + INSTANT BILL UPDATE:
- Decorative typed name signature "Suresh Jadhav" appears on printable service bills.
- Customer can print/save a bill as PDF immediately after submitting an application.
- Admin can print/save a bill from the application list.
- This is NOT a certificate-based DSC, government eSign, or legally verified electronic signature.
- UPI payment is not automatically verified; verify credits separately.
- This ZIP is PWA/app source, not a signed Android APK.
