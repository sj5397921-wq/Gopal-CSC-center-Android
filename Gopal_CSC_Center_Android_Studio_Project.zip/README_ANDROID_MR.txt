GOPAL CSC CENTER - ANDROID PROJECT SOURCE

या ZIP मध्ये Android Studio मध्ये उघडता येणारा Android WebView project आणि अॅपचे web assets आहेत.

APK बनवण्याची पद्धत:
1. संगणकावर Android Studio (आवश्यक Android SDK सहित) स्थापित करा.
2. Android Studio > Open निवडा आणि हा extracted Gopal_CSC_Android_Project फोल्डर निवडा.
3. Gradle sync पूर्ण होऊ द्या. Android SDK Platform 35 आणि Android Gradle Plugin साठी इंटरनेट आवश्यक असू शकते.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) निवडा.
5. चाचणीसाठी तयार झालेला debug APK Android Studio च्या notification मधील Locate वरून मिळेल.
6. सार्वजनिक वितरणासाठी Build > Generate Signed Bundle / APK वापरून स्वतःची सुरक्षित signing key तयार करा आणि ती सुरक्षित ठेवा.

महत्त्वाच्या मर्यादा:
- हा Android Studio source project आहे; आधीच तयार केलेला APK नाही.
- अॅपचा सध्याचा डेटा local device/browser storage मध्ये राहतो; अनेक ग्राहकांच्या फोनमध्ये डेटा एकत्र दिसणार नाही.
- UPI link फक्त पेमेंट अॅप उघडते; पेमेंट आपोआप verify होत नाही.
- बिलावरील "Suresh Jadhav" ही सजावटीची typed signature आहे; DSC किंवा सरकारी eSign नाही.
- बिलातील browser print dialog WebView/Android वर वेगळे वर्तन करू शकते; प्रत्यक्ष डिव्हाइसवर तपासणी आवश्यक.
- प्रत्यक्ष ग्राहक वापरासाठी सुरक्षित server/database, admin authentication, backup, payment verification आणि privacy/security review आवश्यक आहे.
